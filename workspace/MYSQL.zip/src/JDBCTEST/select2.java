package JDBCTEST;

public class select2 {

}
