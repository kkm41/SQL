package com.himedia.board.controller;

import com.himedia.board.controller.action.Action;
import com.himedia.board.controller.action.LoginAction;
import com.himedia.board.controller.action.LoginFormAction;

public class ActionFactory {
	//싱글톤 클래스
	
	private static ActionFactory itc =new ActionFactory();
	public static ActionFactory getInstace() {
		return itc;
	}
	
	//command 값에 따라 해당 클래스의 인스턴스를 Action 참조 변수에 조립하는 역할
	public Action getAction(String command) {
		Action ac = null;
		if(command.equals("loginForm")) ac = new LoginFormAction();
		else if(command.equals("login")) ac = new LoginAction();
		
		
		return ac;
	}
	

}
